package com.example.heloworld

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var alert = findViewById<Button>(R.id.alert)
        var show = findViewById<Button>(R.id.show)
        var print = findViewById<Button>(R.id.print)
        var name = findViewById<EditText>(R.id.name)
        var loc = findViewById<EditText>(R.id.location)
        var mobile = findViewById<EditText>(R.id.mobile)
        var view = findViewById<TextView>(R.id.view)
        var mylayout = findViewById<ConstraintLayout>(R.id.clmain)




        alert.setOnClickListener(){
            Toast.makeText(applicationContext, "[${name.text} , ${loc.text} , ${mobile.text}]", Toast.LENGTH_LONG).show()
        }

        show.setOnClickListener(){
            view.text = "[${name.text} , ${loc.text} , ${mobile.text}]"
        }

        print.setOnClickListener(){
            val intent = Intent(this, Printout::class.java)
            intent.putExtra("info","${name.text} \n ${loc.text} \n ${mobile.text}")
            startActivity(intent)


        }




    }
}